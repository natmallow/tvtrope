<?php




class puzzle{
    
    public $name = 'puzzle';
    
    public $aSegments = [];
    
    public $aPoints = [];

    public $aMasterSegments = [];
    
    public $aPass = [];
    
    public $aFail = [];
             //testing

    public $aReturnRun = [];

    public $iAttempts = []; 

    public function addPoint($sPoint){
        //adds a point to the array Of point
        $this->aPoints[$sPoint] = [];
        return $this;
    }
    
    public function addAjacentPoints(array $aPoint){
        //foreach point there are rules
        //first item in the array is the starting point all other items 
        
        if (!isset($this->aPoints[$aPoint[0]]) || 2 > count($aPoint)) {
            echo "The point for {$aPoint[0]} is not set";
            return FALSE;
        }
        
        if (2 > count($aPoint)) {
            echo "Their are no ajacent points set for {$aPoint[0]}";
            return FALSE;
        }        
        
        $sCentralPoint = $aPoint[0];
        array_shift($aPoint);
        
        foreach ($aPoint as $value) {
            $this->aSegments[$sCentralPoint][$value] = null;
            $this->aMasterSegments[$sCentralPoint.'->'.$value] = $value.'->'.$sCentralPoint;
        }     
        
        $this->aMaster = array_merge($this->aSegments, $this->aMasterSegments);
        return $this;
    }

    public function run($sStartPoint){
        //start with this point
        //set master segments 
        echo "<pre>";

        print_r($this->aMaster);
        print_r($this->aSegments);
        // exit();
        
        foreach ($this->aSegments[$sStartPoint] as $key => $val) {
          //  $aReturnRun
          $this->moveToNext($key, $this->aSegments, $sStartPoint);
        }
        
    }
    
    public function moveToNext($sStartPoint, $aSegmentsRemaining, $sSolution = ''){
        // check if can move and move
        // if move is not valid run end
//        $aSegmentsRemaining = $aSegmentsRemaining;
        
        $sNextStartPoint = array_keys($aSegmentsRemaining[$sStartPoint])[0];
        $sNextRemainingSegments = $aSegmentsRemaining;
        
        if(1 > count($sNextRemainingSegments)){
            $this->aPass[] = $sSolution;
        }elseif (0 == count($sNextRemainingSegments[$sStartPoint])) {
            $this->aFail[] = $sSolution;
        } else {
            $sSolution .= ('' == $sSolution)? $sStartPoint : '->'.$sStartPoint;
        
            
            
//            var_dump($sStartPoint);
//            var_dump($sNextStartPoint);
            
;
            
            
            unset($sNextRemainingSegments[$sStartPoint][$sNextStartPoint]);
            unset($sNextRemainingSegments[$sNextStartPoint][$sStartPoint]);
            
//            print_r($aSegmentsRemaining);
            
            $this->moveToNext($sNextStartPoint, $sNextRemainingSegments, $sSolution);
        }
        return;
    }
    
    public function setSolution(){
        
    }

    public function reset() {
        // return the state of the solutions array 
        // print to page
        // reset the value to move to next solution
    }
    
    public function show(){
        print_r($this->aPass);
        print_r($this->aFail);
    }
    
    
}

$p = new puzzle();
$p->addPoint('a')
    ->addPoint('b')
    ->addPoint('c')
    ->addPoint('d')
    ->addPoint('e');

$p->addAjacentPoints(['e','c','d'])
    ->addAjacentPoints(['c','e','d','a','b'])
    ->addAjacentPoints(['d','e','c','a','b'])
    ->addAjacentPoints(['a','c','d','b'])
    ->addAjacentPoints(['b','c','d','a']);


$p->run('a');

$p->show();






