<?php



class point{
	
	private $aPoint = [];
        private $sPoint;
        
        
        public function __construct($sPoint) {
            
            $this->sPoint = $sPoint;
            
        }
        
        public function addPoint(point $point) {
            
           $this->aPoint[] =  $point;
           return $this;
        }
	
        public function getPointName(){
            return $this->sPoint;
        }

}


class segmentChecker{
    
    public static $aValueSet = [];
    
    public function addValueSet(point $startPoint, point $endPoint){
        //check if exists in aValueSet
        $this->aValueSet[$startPoint->getPointName()][$endPoint->getPointName()] = null;
    }
    
    public function checkValueSegment($pointOne, $pointTwo){
        //check the object 1->2 or 2->1
        if (
                isset(self::$aValueSet[$pointOne][$pointTwo]) ||
                isset(self::$aValueSet[$pointTwo][$pointOne])
            ){
                return FALSE;
        }
        return TRUE;
    }
}

class segment{
    
    // store the sets
    private static $segments = [];
    
    public static function addAjacentPoints($sStartPoint, array $aPoints){
    
        foreach ($aPoints as $val) {
            self::$segments[$sStartPoint][]= $val; 
        }
        
        
    }
        
}

//sudo
// [e,c,a,b,c,d,a]
 $a = new point('a');
 $b = new point('b');
 $c = new point('c');
 $d = new point('d');
 $e = new point('e');

 $a->addPoint($c)->addPoint($d)->addPoint($b);
 
 echo $a->getPointName();
//$a->addAjacentPoints($c, $d, $b);
 
 
 
 
 
//   $a->addAjacentPoints($c, $d, $b);
//   $b->addAjacentPoints($a, $c, $d);
//   $c->addAjacentPoints($a, $b, $d, $e);
//   $d->addAjacentPoints($b, $a, $c, $e);
//   $e->addAjacentPoints($c, $d);

// $a->addAjacentPoints($c,$b,$d);
// $a->getSegments() // array

// / store all the segments
// new point(d,[e,c,b,a])






?>